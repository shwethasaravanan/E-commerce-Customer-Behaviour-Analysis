# Load necessary libraries
library(dplyr)
library(ggplot2)
library(cluster)
library(factoextra)
library(car)

# Load Dataset
data <- read.csv("C:/Users/Shwetha/Downloads/archive/ecommerce_data.csv")

# View the structure of the dataset
str(data)
#-------------------------------------

# Data Cleaning Steps
## Handling missing values (imputation with mean or median)
data$Total.Spend <- ifelse(is.na(data$Total.Spend), median(data$Total.Spend, na.rm = TRUE), data$Total.Spend)
data$Items.Purchased <- ifelse(is.na(data$Items.Purchased), median(data$Items.Purchased, na.rm = TRUE), data$Items.Purchased)
data$Days.Since.Last.Purchase <- ifelse(is.na(data$Days.Since.Last.Purchase), median(data$Days.Since.Last.Purchase, na.rm = TRUE), data$Days.Since.Last.Purchase)
data$Average.Rating <- ifelse(is.na(data$Average.Rating), median(data$Average.Rating, na.rm = TRUE), data$Average.Rating)

## Outlier Treatment
z_scores <- scale(data[, c("Total.Spend", "Items.Purchased", "Days.Since.Last.Purchase", "Average.Rating")])


data <- data[apply(z_scores, 1, function(row) all(abs(row) <= 3)), ]

## Encoding categorical variables
data$Membership.Type <- as.factor(data$Membership.Type)
data$Satisfaction.Level <- as.factor(data$Satisfaction.Level)

# Normalize numeric columns for clustering
scaled_data <- data %>%
  select(Total.Spend, Items.Purchased, Days.Since.Last.Purchase, Average.Rating) %>%
  scale()

#--------------------------------------------

# K-Means Clustering
set.seed(123)
wss <- sapply(1:10, function(k) {
  kmeans(scaled_data, k, nstart = 20)$tot.withinss
})
optimal_clusters <- which.min(diff(diff(wss))) + 1

kmeans_model <- kmeans(scaled_data, centers = optimal_clusters, nstart = 20)
data$Cluster <- as.factor(kmeans_model$cluster)
plot(1:10, wss, type="b", xlab="Number of Clusters", ylab="Within-Cluster Sum of Squares")

library(plotly)

# Create a plotly plot
p <- plot_ly(x = 1:10, y = wss, type = 'scatter', mode = 'lines+markers',
             text = wss, # Add the WSS values as hover text
             hovertemplate = "%{text}")
p

# Visualize Clusters
fviz_cluster(kmeans_model, data = scaled_data, geom = "point", ellipse.type = "norm") +
  labs(title = "Customer Segmentation",
       x = "Cluster",
       y = "Spending Score")

#-----------------------------------------------------
# K-Means Clustering after 3 clusters
set.seed(123)
wss <- sapply(1:4, function(k) {
  kmeans(scaled_data, k, nstart = 20)$tot.withinss
})
optimal_clusters <- which.min(diff(diff(wss))) + 1

kmeans_model <- kmeans(scaled_data, centers = optimal_clusters, nstart = 20)
data$Cluster <- as.factor(kmeans_model$cluster)
plot(1:4, wss, type="b", xlab="Number of Clusters", ylab="Within-Cluster Sum of Squares")

library(plotly)

# Create a plotly plot
p <- plot_ly(x = 1:4, y = wss, type = 'scatter', mode = 'lines+markers',
             text = wss, # Add the WSS values as hover text
             hovertemplate = "%{text}")

# Add annotations to highlight the elbow point
add_annotations(p,
                x = optimal_clusters,
                y = wss[optimal_clusters],
                text = "Elbow Point",
                showarrow = TRUE,
                arrowhead = 6,
                ax = 20,
                ay = -40)

# Visualize Clusters with Custom Ellipse Colors
fviz_cluster(kmeans_model, data = scaled_data, geom = "point", ellipse.type = "norm", 
             ellipse.level = 0.95, # Optional: To adjust the confidence level of the ellipse
             palette = c("maroon", "skyblue", "purple")) +  # Assign specific colors to the ellipses
  labs(title = "Customer Segmentation",
       x = "Cluster",
       y = "Spending Score")


# Check the cluster centers
kmeans_model$centers
# Add cluster assignments to data
data$Cluster <- kmeans_model$cluster

# Calculate the mean of relevant features (e.g., spending score)
aggregate(data$Total.Spend ~ data$Cluster, data, mean)
# Boxplot of spending score by cluster
ggplot(data, aes(x = factor(Cluster), y = Total.Spend)) +
  geom_boxplot() +
  labs(x = "Cluster", y = "Spending Score", title = "Spending Score by Cluster")

#----------------------------------------------------------------

# ANOVA for Membership Analysis
anova_results <- aov(Total.Spend ~ Membership.Type, data = data)
summary(anova_results)

# Visualize Membership Influence with Custom Colors
ggplot(data, aes(x = Membership.Type, y = Total.Spend, fill = Membership.Type)) +
  geom_boxplot() +
  scale_fill_manual(values = c("maroon", "skyblue", "purple")) +  # Add custom colors here
  labs(title = "Total Spend by Membership Type", x = "Membership Type", y = "Total Spend")

#-----------------------------------------

# Regression Analysis
## Logistic Regression (Satisfied/Not Satisfied)
data$Is_Satisfied <- ifelse(data$Satisfaction.Level == "Satisfied", 1, 0)
logistic_model <- glm(Is_Satisfied ~ Total.Spend + Items.Purchased + Days.Since.Last.Purchase + Average.Rating + Age, 
                      data = data, family = binomial)
summary(logistic_model)

## Linear Regression (Continuous Satisfaction Level)
linear_model <- lm(as.numeric(Satisfaction.Level) ~ Total.Spend + Items.Purchased + Days.Since.Last.Purchase + Average.Rating + Age, 
                   data = data)
summary(linear_model)

# Visualize Regression
ggplot(data, aes(x = Total.Spend, y = as.numeric(Satisfaction.Level))) +
  geom_point() +
  geom_smooth(method = "lm") +
  labs(title = "Satisfaction Level vs. Total Spend", x = "Total Spend", y = "Satisfaction Level")
